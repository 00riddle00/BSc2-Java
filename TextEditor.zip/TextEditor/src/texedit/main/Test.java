package texedit.main;

/**
 * Class which tests the functionality of the text editor
 */
public class Test {

    /**
     * @param args - ...
     */
    public static void main(String[] args) {
        TextEditor editor = new TextEditor();
        editor.run();
    }
}
